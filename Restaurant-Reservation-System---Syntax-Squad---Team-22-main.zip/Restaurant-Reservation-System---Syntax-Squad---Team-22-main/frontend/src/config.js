// Configuration constants
const EMAILJS_PUBLIC_KEY = "7CQHXp502_e6kFQcb"; // Replace with your actual key
const EMAILJS_SERVICE_ID = "service_9rrhczs";
const EMAILJS_TEMPLATE_ID = "template_2pz1h3y";
const RESTAURANT_INFO = {
    name: "Fog & Flame",
    phone: "+44 20 7123 4567",
    address: "123 Restaurant Street, London, United Kingdom"
};